Here is a guide on how to use this program:

1. Get your transcript from a school official with e-okul access (bknz Mustafa abi)
2. Make sure its Turkish, excel and DOESN'T say "(data only)". There are 2 excel files so its important to make sure that it isn't the data only version.
3. Make sure that its a Turkish Excel Transcript!!! This program won't work with any other typr of transcript!
3. Run the program from the exe file. (its windows only)
4. Rest should be pretty self explanatory. There are lots of pop-up windows explaining various errors and other such things. READ THEM.
5. Apply somewhere with your amazing IB formatted Transcript
6. ??????
7. Profit.